# Social Icons #hover

A Pen created on CodePen.

Original URL: [https://codepen.io/byclarissacamurca/pen/xbgaqmy](https://codepen.io/byclarissacamurca/pen/xbgaqmy).

